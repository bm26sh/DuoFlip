package com.example.flipduo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.IBinder
import android.view.WindowManager

class FoldService : Service(), SensorEventListener {
    // 이 각도(도) 아래로 내려가면 닫히는 중으로 보고 효과를 시작해요. 기기에 맞게 조절하세요.
    private val startAngle = 110f

    private lateinit var wm: WindowManager
    private var overlay: OverlayView? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("fold", "Flip Duo", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "fold")
            .setContentTitle("Flip Duo 실행 중")
            .setSmallIcon(android.R.drawable.ic_menu_rotate)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)

        wm = getSystemService(WindowManager::class.java)
        val sm = getSystemService(SensorManager::class.java)
        sm.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val angle = e.values[0]
        val p = ((startAngle - angle) / startAngle).coerceIn(0f, 1f)
        if (p > 0f && overlay == null) showOverlay()
        overlay?.target = p
    }

    private fun showOverlay() {
        val v = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        v.onSettledOpen = { removeOverlay() }
        wm.addView(v, lp)
        overlay = v
    }

    private fun removeOverlay() {
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
    }

    override fun onDestroy() {
        getSystemService(SensorManager::class.java).unregisterListener(this)
        removeOverlay()
        super.onDestroy()
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
    override fun onBind(i: Intent?): IBinder? = null
}
