package com.example.flipduo

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/** 닫힘 진행도(target 0..1)를 스프링으로 따라가며 배경 그라데이션, 빛 띠, 어두워짐을 그려요. */
class OverlayView(c: Context) : View(c) {
    var target = 0f
    var onSettledOpen: (() -> Unit)? = null

    private var x = 0f
    private var v = 0f
    private var last = System.nanoTime()
    private val fill = Paint()
    private val band = Paint()
    private val dark = Paint().apply { color = Color.BLACK }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        fill.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            intArrayOf(0xFF2B1F63.toInt(), 0xFF7D3A8F.toInt(), 0xFFE0597A.toInt()), null, Shader.TileMode.CLAMP)
        band.shader = LinearGradient(0f, 0f, 0f, 240f,
            intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = min(0.033f, (now - last) / 1e9f)
        last = now
        v += (100f * (target - x) - 12f * v) * dt   // 스프링: 목표를 살짝 넘었다가 돌아와요
        x += v * dt
        val p = x.coerceIn(0f, 1f)
        val w = width.toFloat()
        val h = height.toFloat()

        fill.alpha = (p * 235).toInt()
        canvas.drawRect(0f, 0f, w, h, fill)

        band.alpha = (sin(PI * p) * 255).toInt().coerceIn(0, 255)
        canvas.save()
        canvas.translate(0f, p * h - 120f)
        canvas.drawRect(0f, 0f, w, 240f, band)
        canvas.restore()

        dark.alpha = (p * p * p * 255).toInt()   // 거의 닫히면 화면이 꺼지듯 어두워져요
        canvas.drawRect(0f, 0f, w, h, dark)

        if (abs(v) > 0.001f || abs(target - x) > 0.001f) postInvalidateOnAnimation()
        else if (target == 0f) onSettledOpen?.invoke()
    }
}
