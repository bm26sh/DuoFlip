package com.example.flipduo

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/**
 * 캡처한 화면을 닫힘 진행도(p)에 따라 아래쪽으로 눌러 담고,
 * 블러 + 그라데이션 배경 + 빛 띠 + 어두워짐으로 바꿔요. 스프링으로 부드럽게 따라가요.
 */
class OverlayView(c: Context, private val bmp: Bitmap?) : View(c) {
    var onSettledOpen: (() -> Unit)? = null
    var target = 0f
        set(value) {
            field = value
            if (!running) { running = true; last = System.nanoTime(); postOnAnimation(tick) }
        }

    private var x = 0f
    private var v = 0f
    private var running = false
    private var last = System.nanoTime()
    private var lastR = -1

    private val fill = Paint()
    private val band = Paint()
    private val dark = Paint().apply { color = Color.BLACK }
    private val bp = Paint(Paint.FILTER_BITMAP_FLAG)
    private val src = Rect()
    private val dst = RectF()

    private fun sm(a: Float, b: Float, t: Float): Float {
        val u = ((t - a) / (b - a)).coerceIn(0f, 1f)
        return u * u * (3 - 2 * u)
    }

    private val tick = object : Runnable {
        override fun run() {
            val now = System.nanoTime()
            val dt = min(0.033f, (now - last) / 1e9f)
            last = now
            v += (100f * (target - x) - 12f * v) * dt   // 목표를 살짝 넘었다가 돌아오는 스프링
            x += v * dt
            val r = (x.coerceIn(0f, 1f) * 28).toInt()
            if (r != lastR) {
                lastR = r
                setRenderEffect(if (r > 0) RenderEffect.createBlurEffect(r.toFloat(), r.toFloat(), Shader.TileMode.CLAMP) else null)
            }
            invalidate()
            if (abs(v) > 0.001f || abs(target - x) > 0.001f) postOnAnimation(this)
            else {
                running = false
                if (target == 0f) onSettledOpen?.invoke()
            }
        }
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        fill.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            intArrayOf(0xFF2B1F63.toInt(), 0xFF7D3A8F.toInt(), 0xFFE0597A.toInt()), null, Shader.TileMode.CLAMP)
        band.shader = LinearGradient(0f, 0f, 0f, 240f,
            intArrayOf(0x00FFFFFF, 0x66FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
    }

    override fun onDraw(canvas: Canvas) {
        val p = x.coerceIn(0f, 1f)
        val w = width.toFloat()
        val h = height.toFloat()

        // 배경: 캡처가 있으면 항상 불투명(처음엔 캡처가 화면을 완전히 덮어 티가 안 나요)
        fill.alpha = if (bmp != null) 255 else (p * 235).toInt()
        canvas.drawRect(0f, 0f, w, h, fill)

        if (bmp != null) {
            src.set(0, 0, bmp.width, bmp.height)
            dst.set(0f, p * h * 0.5f, w, h)          // 화면이 아래쪽 절반으로 눌려 들어가요
            bp.alpha = (255 * (1f - sm(.6f, 1f, p))).toInt()
            canvas.drawBitmap(bmp, src, dst, bp)
        }

        band.alpha = (sin(PI * p) * 255).toInt().coerceIn(0, 255)
        canvas.save()
        canvas.translate(0f, p * h - 120f)
        canvas.drawRect(0f, 0f, w, 240f, band)
        canvas.restore()

        dark.alpha = (p * p * p * 255).toInt()        // 거의 닫히면 화면이 꺼지듯 어두워져요
        canvas.drawRect(0f, 0f, w, h, dark)
    }
}
