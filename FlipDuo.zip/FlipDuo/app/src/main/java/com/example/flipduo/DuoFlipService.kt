package com.example.flipduo

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.HardwareBuffer
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.util.Log
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs

class DuoFlipService : AccessibilityService(), SensorEventListener {
    companion object {
        @Volatile var instance: DuoFlipService? = null
        @Volatile var lastAngle = -1f
        @Volatile var lastFail = 0
        @Volatile var events = 0
        val logs = java.util.concurrent.ConcurrentLinkedDeque<String>()
        fun dbg(m: String) {
            Log.d("DuoFlip", m)
            val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            logs.addFirst("$t $m")
            while (logs.size > 25) logs.removeLast()
        }
    }

    // 각도(도). 닫히기 시작하면 바로 캡처하고, 이 범위에서 효과가 0→1로 진행돼요.
    private val startAngle = 170f   // 효과 시작
    private val resetAngle = 176f   // 이 이상이면 완전히 펼친 것으로 보고 초기화
    private val defaultEnd = 60f    // 화면이 꺼지는 각도를 학습하기 전 기본값(효과 끝)

    private enum class State { IDLE, CAPTURING, READY }
    private var state = State.IDLE
    private var demoRunning = false
    private var prevAngle = -1f
    private var lastMove = 0L
    private var shotTime = 0L
    private var lastEventAngle = -1f
    private var coarseUntil = 0L   // 센서가 값을 크게 건너뛸 때(예: 180→90) 시간 기반 애니메이션으로 전환
    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var overlay: OverlayView? = null
    private var shot: Bitmap? = null
    private var buf: HardwareBuffer? = null

    private val prefs get() = getSharedPreferences("duoflip", MODE_PRIVATE)
    private val endAngle get() = prefs.getFloat("offAngle", defaultEnd).coerceIn(20f, startAngle - 40f)

    // 닫혀서 화면이 꺼지면 그 각도를 학습하고, 보이지 않는 오버레이는 치워요.
    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val a = lastAngle
            if (a in 0f..150f) {
                val old = prefs.getFloat("offAngle", -1f)
                val v = if (old < 0f) a else (old + a) / 2f
                prefs.edit().putFloat("offAngle", v).apply()
                dbg("화면 꺼짐 각도=$a → 효과 끝각도 ${v}")
            }
            overlay?.let { runCatching { wm.removeView(it) } }
            overlay = null
            state = State.IDLE
            cleanup()
        }
    }

    private val idleCheck = Runnable {
        if (overlay != null && !demoRunning && lastAngle > endAngle + 8f) overlay?.target = 0f
    }

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WindowManager::class.java)
        val sm = getSystemService(SensorManager::class.java)
        sm.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST, 0)
        }
        registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onSensorChanged(e: SensorEvent) {
        val angle = e.values[0]
        lastAngle = angle
        events++
        if (events % 30 == 0) dbg("angle=$angle state=$state overlay=${overlay != null} locked=${isLocked()}")
        if (demoRunning) return
        val now = SystemClock.elapsedRealtime()
        val moved = prevAngle < 0f || abs(angle - prevAngle) >= 1f
        if (moved) { prevAngle = angle; lastMove = now }
        val closingDir = lastEventAngle < 0f || angle < lastEventAngle
        if (lastEventAngle >= 0f && abs(angle - lastEventAngle) >= 15f) {
            coarseUntil = now + 1500
            dbg("센서 값이 크게 건너뜀 $lastEventAngle → $angle (시간 기반 애니메이션)")
        }
        lastEventAngle = angle

        // 애니메이션이 꺼져 있으면 효과 없이 정리
        if (!prefs.getBoolean("enabled", true)) {
            overlay?.target = 0f
            if (overlay == null) { state = State.IDLE; cleanup() }
            return
        }
        if (angle >= resetAngle) {
            overlay?.target = 0f
            if (overlay == null) { state = State.IDLE; cleanup() }
            return
        }
        // 움직이기 시작하면 바로 캡처 (오래된 캡처면 다시)
        if (overlay == null && moved &&
            (state == State.IDLE || (state == State.READY && now - shotTime > 1000))) {
            cleanup()
            state = State.CAPTURING
            capture(null)
        }
        val p = ((startAngle - angle) / (startAngle - endAngle)).coerceIn(0f, 1f)
        if (state == State.READY && p > 0f && moved && overlay == null) showOverlay()
        val coarse = now < coarseUntil
        // 센서가 거칠면 각도 대신 방향으로 판단: 닫히는 중이면 끝까지, 열리는 중이면 되돌려요.
        overlay?.target = if (coarse) (if (closingDir) 1f else 0f) else p
        // 움직임이 멈추면(플렉스 모드 등) 효과를 걷어요
        main.removeCallbacks(idleCheck)
        main.postDelayed(idleCheck, if (coarse) 1500L else 350L)
    }

    /** 앱의 "효과 미리보기" 버튼용 */
    fun demo() {
        if (overlay != null || demoRunning) return
        demoRunning = true
        state = State.CAPTURING
        capture {
            showOverlay()
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1500
                addUpdateListener { overlay?.target = it.animatedValue as Float }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: Animator) {
                        main.postDelayed({ overlay?.target = 0f; demoRunning = false }, 400)
                    }
                })
                start()
            }
        }
    }

    private fun capture(done: (() -> Unit)?) {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    buf = r.hardwareBuffer
                    shot = buf?.let { Bitmap.wrapHardwareBuffer(it, r.colorSpace) }
                    shotTime = SystemClock.elapsedRealtime()
                    state = State.READY
                    done?.invoke()
                }
                override fun onFailure(code: Int) {
                    lastFail = code
                    dbg("capture FAIL code=$code locked=${isLocked()}")
                    shot = null
                    shotTime = SystemClock.elapsedRealtime()
                    state = State.READY
                    done?.invoke()
                }
            })
        } catch (e: Exception) {
            lastFail = -99
            shot = null
            state = State.READY
            done?.invoke()
        }
    }

    private fun overlayParams(type: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        type,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply {
        layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
    }

    private fun showOverlay() {
        val v = OverlayView(this, shot)
        v.onSettledOpen = {
            runCatching { wm.removeView(v) }
            if (overlay === v) overlay = null
            state = State.IDLE
            cleanup()
        }
        dbg("showOverlay locked=${isLocked()} hasBitmap=${shot != null}")
        var ok = false
        try {
            wm.addView(v, overlayParams(WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY))
            ok = true
        } catch (e: Exception) {
            dbg("addView(접근성) failed: ${e.javaClass.simpleName} ${e.message}")
            if (Settings.canDrawOverlays(this)) {
                try {
                    wm.addView(v, overlayParams(WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY))
                    ok = true
                    dbg("다른 앱 위에 표시 권한으로 재시도 성공")
                } catch (e2: Exception) {
                    dbg("addView(앱 오버레이) failed: ${e2.javaClass.simpleName} ${e2.message}")
                }
            }
        }
        if (ok) overlay = v
    }

    private fun isLocked() = getSystemService(KeyguardManager::class.java).isKeyguardLocked

    private fun cleanup() {
        shot = null
        buf?.close()
        buf = null
    }

    override fun onDestroy() {
        instance = null
        getSystemService(SensorManager::class.java).unregisterListener(this)
        runCatching { unregisterReceiver(screenOff) }
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
        cleanup()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
