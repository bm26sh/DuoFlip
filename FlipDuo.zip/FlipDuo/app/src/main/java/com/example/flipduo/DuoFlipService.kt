package com.example.flipduo

import android.accessibilityservice.AccessibilityService
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.HardwareBuffer
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

class DuoFlipService : AccessibilityService(), SensorEventListener {
    companion object {
        // 앱 화면의 진단 표시용
        @Volatile var instance: DuoFlipService? = null
        @Volatile var lastAngle = -1f
        @Volatile var lastFail = 0
        @Volatile var events = 0
    }

    // 각도(도): 기기에 맞게 조절하세요.
    private val startAngle = 120f      // 이 각도부터 효과 시작
    private val captureAngle = 150f    // 이 각도 아래에서 현재 화면을 미리 캡처
    private val resetAngle = 155f      // 이 각도 이상이면 다시 펼친 것으로 보고 초기화

    private enum class State { IDLE, CAPTURING, READY }
    private var state = State.IDLE
    private var demoRunning = false
    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var overlay: OverlayView? = null
    private var shot: Bitmap? = null
    private var buf: HardwareBuffer? = null

    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(WindowManager::class.java)
        val sm = getSystemService(SensorManager::class.java)
        sm.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val angle = e.values[0]
        lastAngle = angle
        events++
        if (demoRunning) return
        if (angle >= resetAngle) {
            overlay?.target = 0f
            if (overlay == null) { state = State.IDLE; cleanup() }
            return
        }
        if (angle < captureAngle && state == State.IDLE && overlay == null) {
            state = State.CAPTURING
            capture(null)
        }
        val p = ((startAngle - angle) / startAngle).coerceIn(0f, 1f)
        if (state == State.READY && p > 0f && overlay == null) showOverlay()
        overlay?.target = p
    }

    /** 앱의 "효과 테스트" 버튼용: 플립을 접지 않고도 효과를 한 번 재생해요. */
    fun demo() {
        if (overlay != null || demoRunning) return
        demoRunning = true
        state = State.CAPTURING
        capture {
            showOverlay()
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 1500
                addUpdateListener { overlay?.target = it.animatedValue as Float }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(a: Animator) {
                        main.postDelayed({ overlay?.target = 0f; demoRunning = false }, 400)
                    }
                })
                start()
            }
        }
    }

    private fun capture(done: (() -> Unit)?) {
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    buf = r.hardwareBuffer
                    shot = buf?.let { Bitmap.wrapHardwareBuffer(it, r.colorSpace) }
                    state = State.READY
                    done?.invoke()
                }
                override fun onFailure(code: Int) {
                    lastFail = code
                    shot = null   // 캡처 실패 시 어두워지는 효과만 보여줘요
                    state = State.READY
                    done?.invoke()
                }
            })
        } catch (e: Exception) {
            lastFail = -99
            shot = null
            state = State.READY
            done?.invoke()
        }
    }

    private fun showOverlay() {
        val v = OverlayView(this, shot)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }
        v.onSettledOpen = {
            runCatching { wm.removeView(v) }
            overlay = null
            state = State.IDLE
            cleanup()
        }
        wm.addView(v, lp)
        overlay = v
    }

    private fun cleanup() {
        shot = null
        buf?.close()
        buf = null
    }

    override fun onDestroy() {
        instance = null
        getSystemService(SensorManager::class.java).unregisterListener(this)
        overlay?.let { runCatching { wm.removeView(it) } }
        overlay = null
        cleanup()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
