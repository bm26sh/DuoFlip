package com.example.flipduo

import android.app.Activity
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), SensorEventListener {
    private lateinit var status: TextView
    private var angle = -1f
    private var hasSensor = false
    private val h = Handler(Looper.getMainLooper())

    private val refresh = object : Runnable {
        override fun run() {
            val svc = DuoFlipService.instance != null
            status.text = "힌지 센서: ${if (hasSensor) "있음" else "없음"}\n" +
                "현재 각도(앱이 읽음): $angle\n\n" +
                "접근성 서비스: ${if (svc) "켜짐" else "꺼짐"}\n" +
                "서비스가 읽은 각도: ${DuoFlipService.lastAngle}\n" +
                "서비스 센서 이벤트 수: ${DuoFlipService.events}\n" +
                "캡처 실패 코드: ${DuoFlipService.lastFail} (0이면 실패 없음)"
            h.postDelayed(this, 300)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        status = TextView(this).apply { textSize = 16f }
        box.addView(TextView(this).apply {
            text = "DuoFlip\n접근성 설정에서 DuoFlip을 켠 뒤, 플립을 닫아 보세요."
            textSize = 16f
            setPadding(0, 0, 0, 32)
        })
        box.addView(status)
        box.addView(Button(this).apply {
            text = "효과 테스트 (플립 안 접어도 재생)"
            setOnClickListener {
                val s = DuoFlipService.instance
                if (s == null) Toast.makeText(this@MainActivity, "접근성 서비스가 꺼져 있어요", Toast.LENGTH_SHORT).show()
                else s.demo()
            }
        })
        box.addView(Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(box)
    }

    override fun onResume() {
        super.onResume()
        val sm = getSystemService(SensorManager::class.java)
        val s = sm.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
        hasSensor = s != null
        s?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        h.post(refresh)
    }

    override fun onPause() {
        getSystemService(SensorManager::class.java).unregisterListener(this)
        h.removeCallbacks(refresh)
        super.onPause()
    }

    override fun onSensorChanged(e: SensorEvent) { angle = e.values[0] }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
