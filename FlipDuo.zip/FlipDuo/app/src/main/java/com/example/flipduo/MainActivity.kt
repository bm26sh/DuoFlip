package com.example.flipduo

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        box.addView(TextView(this).apply {
            text = "플립을 닫을 때 전체 화면 전환 효과가 나와요.\n1) 다른 앱 위에 표시 권한 허용\n2) 시작 버튼 누르기"
            textSize = 16f
        })
        box.addView(Button(this).apply {
            text = "시작"
            setOnClickListener { start() }
        })
        box.addView(Button(this).apply {
            text = "중지"
            setOnClickListener { stopService(Intent(this@MainActivity, FoldService::class.java)) }
        })
        setContentView(box)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        startForegroundService(Intent(this, FoldService::class.java))
    }
}
