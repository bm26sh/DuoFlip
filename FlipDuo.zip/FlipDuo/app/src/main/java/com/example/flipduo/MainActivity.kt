package com.example.flipduo

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 48, 48, 48)
        }
        box.addView(TextView(this).apply {
            text = "DuoFlip\n\n플립을 닫을 때 현재 화면이 흩어지며 사라지는 효과를 보여줘요.\n\n" +
                "아래 버튼으로 접근성 설정을 열고 → 설치된 앱 → DuoFlip을 켜 주세요.\n" +
                "(화면 내용은 저장하거나 전송하지 않아요.)"
            textSize = 16f
        })
        box.addView(Button(this).apply {
            text = "접근성 설정 열기"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(box)
    }
}
