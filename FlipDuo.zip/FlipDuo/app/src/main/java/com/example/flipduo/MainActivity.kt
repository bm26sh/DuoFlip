package com.example.flipduo

import android.app.Activity
import android.content.ColorStateList
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity(), SensorEventListener {
    private val BG = 0xFF14121F.toInt()
    private val CARD = 0xFF1F1C2E.toInt()
    private val ACC = 0xFFFFB347.toInt()
    private val INK = 0xFFF3F0FF.toInt()
    private val MUTE = 0xFF9A94B8.toInt()
    private val OK = 0xFF7BE0A0.toInt()
    private val WARN = 0xFFFF8A8A.toInt()

    private lateinit var prefs: SharedPreferences
    private lateinit var toggleStatus: TextView
    private lateinit var diag: TextView
    private val checks = mutableListOf<() -> Unit>()
    private var angle = -1f
    private var hasSensor = false
    private var sensorInfo = ""
    private val h = Handler(Looper.getMainLooper())

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private fun label(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(16))
        background = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(CARD) }
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { bottomMargin = dp(12) }
    }

    private fun pill(t: String, filled: Boolean, onClick: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; textSize = 14f
        setTextColor(if (filled) 0xFF1B1200.toInt() else INK)
        background = GradientDrawable().apply {
            cornerRadius = dp(24).toFloat()
            if (filled) setColor(ACC) else { setColor(0x00000000); setStroke(dp(1), 0xFF3A3556.toInt()) }
        }
        setOnClickListener { onClick() }
    }

    private fun permRow(title: String, desc: String, ok: () -> Boolean, onClick: () -> Unit): LinearLayout {
        val c = card()
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        val st = label("", 13f, MUTE)
        col.addView(label(title, 16f, INK, true))
        col.addView(label(desc, 13f, MUTE))
        col.addView(st)
        row.addView(col)
        row.addView(pill("설정", false, onClick))
        c.addView(row)
        checks.add {
            val good = ok()
            st.text = if (good) "✓ 허용됨" else "필요해요"
            st.setTextColor(if (good) OK else WARN)
        }
        return c
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("duoflip", MODE_PRIVATE)
        window.statusBarColor = BG
        window.navigationBarColor = BG

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        root.addView(label("DuoFlip", 30f, INK, true))
        root.addView(label("플립을 닫을 때 화면이 커버 화면으로 이어져요", 14f, MUTE).apply {
            setPadding(0, dp(4), 0, dp(20))
        })

        // 애니메이션 켜기/끄기
        val tc = card()
        val tr = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val tcol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, WRAP, 1f)
        }
        toggleStatus = label("", 13f, MUTE)
        tcol.addView(label("닫기 애니메이션", 18f, INK, true))
        tcol.addView(toggleStatus)
        val sw = Switch(this).apply {
            isChecked = prefs.getBoolean("enabled", true)
            thumbTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(ACC, MUTE))
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(0x66FFB347, 0x33FFFFFF))
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("enabled", on).apply() }
        }
        tr.addView(tcol); tr.addView(sw)
        tc.addView(tr)
        root.addView(tc)

        // 권한
        root.addView(label("권한", 14f, MUTE, true).apply { setPadding(dp(4), dp(8), 0, dp(8)) })
        root.addView(permRow("접근성 (화면 캡처 포함)", "닫을 때 현재 화면을 캡처해요",
            { DuoFlipService.instance != null }) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(permRow("다른 앱 위에 표시", "다른 앱 위에 효과를 띄워요",
            { Settings.canDrawOverlays(this) }) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(permRow("백그라운드 제한 해제", "앱이 꺼지지 않게 해요",
            { getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName) }) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        })

        // 테스트 + 진단
        root.addView(pill("효과 미리보기 (플립 안 접어도 재생)", true) {
            val s = DuoFlipService.instance
            if (s == null) Toast.makeText(this, "접근성 서비스가 꺼져 있어요", Toast.LENGTH_SHORT).show() else s.demo()
        }.apply { layoutParams = LinearLayout.LayoutParams(MATCH, dp(52)).apply { topMargin = dp(8); bottomMargin = dp(12) } })

        diag = label("", 12f, MUTE).apply { visibility = View.GONE; setPadding(dp(4), dp(8), dp(4), dp(8)) }
        root.addView(pill("진단 보기", false) {
            diag.visibility = if (diag.visibility == View.GONE) View.VISIBLE else View.GONE
        }.apply { layoutParams = LinearLayout.LayoutParams(MATCH, dp(48)) })
        root.addView(diag)

        setContentView(ScrollView(this).apply { setBackgroundColor(BG); addView(root) })
    }

    private val refresh = object : Runnable {
        override fun run() {
            checks.forEach { it() }
            val svc = DuoFlipService.instance != null
            val on = prefs.getBoolean("enabled", true)
            toggleStatus.text = when {
                !svc -> "접근성 서비스를 먼저 켜 주세요"
                on -> "켜짐 · 플립을 닫으면 효과가 나와요"
                else -> "꺼짐"
            }
            toggleStatus.setTextColor(if (svc && on) OK else MUTE)
            if (diag.visibility == View.VISIBLE) {
                diag.text = "$sensorInfo\n힌지 센서: ${if (hasSensor) "있음" else "없음"} / 각도(앱): $angle\n" +
                    "서비스 각도: ${DuoFlipService.lastAngle} / 이벤트 수: ${DuoFlipService.events}\n" +
                    "화면 꺼짐 각도(자동 학습): ${prefs.getFloat("offAngle", -1f)}\n" +
                    "캡처 실패 코드: ${DuoFlipService.lastFail} (0이면 없음)\n\n" +
                    "최근 기록:\n" + DuoFlipService.logs.take(12).joinToString("\n")
            }
            h.postDelayed(this, 300)
        }
    }

    override fun onResume() {
        super.onResume()
        val sm = getSystemService(SensorManager::class.java)
        val s = sm.getDefaultSensor(Sensor.TYPE_HINGE_ANGLE)
        hasSensor = s != null
        sensorInfo = (s?.let { "${it.name} / 해상도 ${it.resolution} / 최소지연 ${it.minDelay}us\n" } ?: "힌지 센서 없음\n") +
            "관련 센서: " + sm.getSensorList(Sensor.TYPE_ALL)
                .filter { x -> listOf("hinge", "fold", "angle", "posture", "flip").any { k -> (x.name + x.stringType).lowercase().contains(k) } }
                .joinToString(", ") { x -> x.name }
        s?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_FASTEST) }
        h.post(refresh)
    }

    override fun onPause() {
        getSystemService(SensorManager::class.java).unregisterListener(this)
        h.removeCallbacks(refresh)
        super.onPause()
    }

    override fun onSensorChanged(e: SensorEvent) { angle = e.values[0] }
    override fun onAccuracyChanged(s: Sensor?, a: Int) {}
}
