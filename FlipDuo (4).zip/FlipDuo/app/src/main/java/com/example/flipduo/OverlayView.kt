package com.example.flipduo

import android.content.Context
import android.graphics.*
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/**
 * 아이폰 듀오식 전환: 화면이 블러(심도)와 함께 늘어났다가 커버 화면 모양의 영역으로 모이고,
 * 그 자리에 커버 화면 시계가 이어져요. 뒤에는 화면을 흐리고 어둡게 깐 배경을 둬서 검은 빈칸이 없어요.
 */
class OverlayView(c: Context, private val bmp: Bitmap?) : View(c) {
    var onSettledOpen: (() -> Unit)? = null
    var target = 0f
        set(value) {
            field = value
            if (!running) { running = true; last = System.nanoTime(); postOnAnimation(tick) }
        }

    private var x = 0f
    private var v = 0f
    private var running = false
    private var last = System.nanoTime()
    private var lastR = -1

    private val bp = Paint(Paint.FILTER_BITMAP_FLAG)
    private val panel = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF15131F.toInt() }
    private val clock = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD
    }
    private val cm = ColorMatrix()
    private val src = Rect()
    private val full = RectF()
    private val dst = RectF()
    private val cover = RectF()
    private val path = Path()
    private val fmt = SimpleDateFormat("H:mm", Locale.getDefault())

    private fun sm(a: Float, b: Float, t: Float): Float {
        val u = ((t - a) / (b - a)).coerceIn(0f, 1f)
        return u * u * (3 - 2 * u)
    }
    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    private val tick = object : Runnable {
        override fun run() {
            val now = System.nanoTime()
            val dt = min(0.033f, (now - last) / 1e9f)
            last = now
            v += (100f * (target - x) - 12f * v) * dt   // 목표를 살짝 넘었다가 돌아오는 스프링
            x += v * dt
            val p = x.coerceIn(0f, 1f)
            // 블러는 전환 중간에 가장 세고, 끝에서는 약해져서 커버 시계가 또렷해요
            val r = (sin(PI * p) * 30 + p * 3).toInt()
            if (r != lastR) {
                lastR = r
                setRenderEffect(if (r > 0) RenderEffect.createBlurEffect(r.toFloat(), r.toFloat(), Shader.TileMode.CLAMP) else null)
            }
            invalidate()
            if (abs(v) > 0.001f || abs(target - x) > 0.001f) postOnAnimation(this)
            else {
                running = false
                if (target == 0f) onSettledOpen?.invoke()
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        val p = x.coerceIn(0f, 1f)
        val w = width.toFloat()
        val h = height.toFloat()
        full.set(0f, 0f, w, h)
        cover.set(w * 0.06f, h * 0.05f, w * 0.94f, h * 0.47f)   // 커버 화면 위치(위쪽 절반)
        val e = sm(0f, 1f, p)

        canvas.drawColor(Color.BLACK)
        if (bmp != null) {
            src.set(0, 0, bmp.width, bmp.height)
            // 뒤 배경: 같은 화면을 전체로 깔고 점점 어둡게 (검은 빈칸 방지)
            val b = 1f - 0.7f * p
            cm.setScale(b, b, b, 1f)
            bp.colorFilter = ColorMatrixColorFilter(cm)
            bp.alpha = 255
            canvas.drawBitmap(bmp, src, full, bp)
            bp.colorFilter = null
        } else {
            panel.alpha = (p * 235).toInt()
            canvas.drawRect(full, panel)
        }

        // 앞 화면: 가로로 살짝 늘어났다가 커버 화면 모양으로 모여요
        val bulge = sin(PI * p).toFloat() * 0.06f
        dst.set(
            lerp(0f, cover.left, e) - w * bulge, lerp(0f, cover.top, e),
            lerp(w, cover.right, e) + w * bulge, lerp(h, cover.bottom, e)
        )
        val rad = lerp(0f, 56f, e)
        canvas.save()
        path.reset()
        path.addRoundRect(dst, rad, rad, Path.Direction.CW)
        canvas.clipPath(path)
        if (bmp != null) {
            bp.alpha = (255 * (1f - sm(.8f, 1f, p))).toInt()
            canvas.drawBitmap(bmp, src, dst, bp)
        } else {
            panel.alpha = (e * 255).toInt()
            canvas.drawRect(dst, panel)
        }
        canvas.restore()

        // 커버 화면 시계: 화면이 모이면 그 자리에 이어서 나타나요
        val ca = sm(.55f, .9f, p)
        if (ca > 0f) {
            clock.alpha = (ca * 255).toInt()
            clock.textSize = cover.height() * 0.3f
            canvas.drawText(fmt.format(Date()), cover.centerX(), cover.centerY() + clock.textSize * 0.35f, clock)
        }
    }
}
