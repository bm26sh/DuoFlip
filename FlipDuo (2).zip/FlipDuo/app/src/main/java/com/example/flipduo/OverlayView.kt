package com.example.flipduo

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/**
 * 아이폰 듀오식 전환: 인터페이스가 블러(심도 효과)와 함께 늘어나고 줄어들며
 * 커버 화면 크기로 이어지는 느낌을 내요. 캡처한 화면을 닫힘 진행도(p)에 따라 변형해요.
 */
class OverlayView(c: Context, private val bmp: Bitmap?) : View(c) {
    var onSettledOpen: (() -> Unit)? = null
    var target = 0f
        set(value) {
            field = value
            if (!running) { running = true; last = System.nanoTime(); postOnAnimation(tick) }
        }

    private var x = 0f
    private var v = 0f
    private var running = false
    private var last = System.nanoTime()
    private var lastR = -1

    private val base = Paint().apply { color = Color.BLACK }
    private val bp = Paint(Paint.FILTER_BITMAP_FLAG)
    private val src = Rect()
    private val dst = RectF()

    private fun sm(a: Float, b: Float, t: Float): Float {
        val u = ((t - a) / (b - a)).coerceIn(0f, 1f)
        return u * u * (3 - 2 * u)
    }

    private val tick = object : Runnable {
        override fun run() {
            val now = System.nanoTime()
            val dt = min(0.033f, (now - last) / 1e9f)
            last = now
            v += (100f * (target - x) - 12f * v) * dt   // 목표를 살짝 넘었다가 돌아오는 스프링
            x += v * dt
            val r = (x.coerceIn(0f, 1f) * 36).toInt()    // 심도(블러) 세기
            if (r != lastR) {
                lastR = r
                setRenderEffect(if (r > 0) RenderEffect.createBlurEffect(r.toFloat(), r.toFloat(), Shader.TileMode.CLAMP) else null)
            }
            invalidate()
            if (abs(v) > 0.001f || abs(target - x) > 0.001f) postOnAnimation(this)
            else {
                running = false
                if (target == 0f) onSettledOpen?.invoke()
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        val p = x.coerceIn(0f, 1f)
        val w = width.toFloat()
        val h = height.toFloat()

        // 캡처가 있으면 배경이 항상 불투명(처음엔 캡처가 화면을 완전히 덮어 티가 안 나요)
        base.alpha = if (bmp != null) 255 else (p * 235).toInt()
        canvas.drawRect(0f, 0f, w, h, base)

        if (bmp != null) {
            val bulge = sin(PI * p).toFloat() * 0.06f        // 중간에 가로로 살짝 늘어나는 탄성
            src.set(0, 0, bmp.width, bmp.height)
            dst.set(-w * bulge, 0f, w * (1f + bulge), h * (1f - 0.5f * p))   // 커버 화면(위쪽 절반) 크기로 줄어들어요
            bp.alpha = (255 * (1f - sm(.7f, 1f, p))).toInt()
            canvas.drawBitmap(bmp, src, dst, bp)
        }
    }
}
